echo "Gathering WAS information..."
# Find the WebSphere* folder
if [[ -n $(find /opt/ -maxdepth 1 -type d -name 'WebSphere*') ]]; then
  WASHOME=$(find /opt/ -maxdepth 1 -type d -name 'WebSphere*')
elif [[ -n $(find /opt/IBM/ -maxdepth 1 -type d -name 'WebSphere*') ]]; then
  WASHOME=$(find /opt/IBM/ -maxdepth 1 -type d -name 'WebSphere*')
fi
# Find profiles folder
if [[ -n $(find ${WASHOME} -maxdepth 1 -type d -name 'profiles') ]]; then
  PROFILEHOME=$(find ${WASHOME} -maxdepth 1 -type d -name 'profiles')
elif [[ -n $(find ${WASHOME}/AppServer -maxdepth 1 -type d -name 'profiles') ]]; then
  PROFILEHOME=$(find ${WASHOME}/AppServer -maxdepth 1 -type d -name 'profiles')
fi

installer_location=/home/wasadm/appdynamics-was-agent-installation

"$WASHOME"/AppServer/bin/wsadmin.sh -lang jython -f "$installer_location"/scripts/getServers.py "$installer_location"/serverlist.txt 
echo ""
cat "$installer_location"/serverlist.txt