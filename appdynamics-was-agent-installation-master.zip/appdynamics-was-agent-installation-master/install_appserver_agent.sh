#! /bin/bash

# --------------------------------------------------------------------------------
# Installs the AppDynamics AppServer (Java) Agent to an HSBC RBWM WebSphere server
# Author(s): Morgan Atkins, Michael Warr
# Version: 1.0.0
# --------------------------------------------------------------------------------

set -o pipefail # Make sure we catch errors in pipelines
exec 3>> "${0%.*}.log" # Open log file for appending
script_version="1.4.0"

# Logging Config
logging_level='INFO' # Default log level - may be changed with --debug or --trace
case "$1" in
  --debug)
    logging_level='DEBUG'
    shift
    ;;
  --trace)
    logging_level='TRACE'
    shift
    ;;
esac

# Tracing - don't think too hard about this...
#  Produces a file named like "script_name_20170124232413456.trace"
#  Where the numbers represent YearMonthDayHourMinuteMicroseconds
if [ "$logging_level" = 'TRACE' ]; then
  tracefile="${0%.*}_$(date +'%Y%m%d%H%M%3N').trace"
  exec 4>> "$tracefile"
  PS4="$(printf '%-36s %s\n' ':['"$(date +'%Y/%m/%d %T.%3N')"'] [TRACE]' '${BASH_SOURCE##*/}:${LINENO}+')" # Set prefix format for trace lines
  [[ "$tracefile" ]] && export BASH_XTRACEFD=3 && set -x
fi

# =========
# Variables
# =========

# Configuration
controller_config='controller_config.yml' # Slightly static config
deployment_config='deployment_config.yml' # AppD App/Tier/Node names

# Usage Information
usage='Usage: install_appserver_agent.sh [--debug][-h|-v] OPTIONS

Installation of AppDynamics Java Agents on WebSphere.

Arguments:
  -h            Show this help message and exit
  -v            Print version number

  -a            Test run, prints config as read by this script
  -s            Selectively install agents to one or more WAS servers/JVMs
  -i            Install the agent for a single WAS server/JVM (prompted)
  -b JVM_NAME   Installs the agent for a single WAS server/JVM (non-interactive)
                WebSphere server (JVM) name of agent to be updated.
  --debug       Increases the default INFO log level to DEBUG'

# =========
# Functions
# =========

# Core Script Functionality

checkXcode () {
    # Tests for non-zero exit codes, then quits with a custom message if necessary
    # Usage: "error_check $?" or "error_check $? 'exit message'"
    local errorlvl="$1"
    local errormsg="$2"
    if [[ -z "$errormsg" ]]; then
    local errormsg=$'\n''###'" Error detected, exiting "'###'
    fi
    if [[ "$errorlvl" -ne 0 ]] || [[ -z "$errorlvl" ]]; then
    echo errormsg:"$errormsg"
    log "$errormsg" 'ERROR'
    exit 1
    fi
}

log () {
  # Writes a message to the log with a full timestamp and log level, "INFO" if not specified.
  # Will write to file descriptor 3, which can be set up via 'exec 3>> "$log_file"' (note the '>>'!)
  # Requires a global variable, "$logging_level"
  # In order of priority, logging levels are: TRACE, DEBUG, INFO, ERROR
  # Example: log 'Something happened'
  #      or: log 'Bad stuff happened' 'ERROR'
  local log_msg="$1"
  local log_lvl="$2"
  local print_as_well="$3"

  if [ ! -z "$print_as_well" ]; then
    printf '%s\n' "$1"
  fi

  if [ -z "$log_lvl" ]; then
    log_lvl="INFO"
  fi
  local log_prefix="$(printf '[%s] [%s]' "$(date +'%Y/%m/%d %T.%3N')" "$log_lvl")"

  local write=1
  case "$logging_level" in
    'INFO')
      # Skip debug messages
      if [ "$log_lvl" = 'DEBUG' ]; then write=0; fi
      ;;
    'ERROR')
      # Write only errors
      if [ "$log_lvl" = 'INFO' ] || [ "$log_lvl" = 'DEBUG' ]; then write=0; fi
      ;;
    *)
      # Write everything
      ;;
  esac

  if [ "$write" = 1 ]; then
    printf '%-36s %s\n' "$log_prefix" "$log_msg" >&3 # Redirecting to file descriptor 3, appends to log file
  fi
}



# Configuration Functions
parse_yaml () {
  # Stack Exchange: https://gist.github.com/pkuczynski/8665367
  log 'Parsing yaml file '\'"$1"\'
  local prefix=$2
  local s='[[:space:]]*' w='[a-zA-Z0-9_]*' fs=$(echo @|tr @ '\034')
  sed -ne "s|^\($s\)\($w\)$s:$s\"\(.*\)\"$s\$|\1$fs\2$fs\3|p" \
       -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p"  $1 |
  awk -F$fs '{
    indent = length($1)/2;
    vname[indent] = $2;
    for (i in vname) {if (i > indent) {delete vname[i]}}
    if (length($3) > 0) {
      vn=""; for (i=0; i<indent; i++) {vn=(vn)(vname[i])("_")}
      printf("%s%s%s=\"%s\"\n", "'$prefix'",vn, $2, $3);
    }
  }'
}

set_config () {
  # Setting the configuration from configuration yaml files
  # Source yaml file as parameters
  # Ymal is used to provide a hierarchy of all jvm's that connect to a given controller
  # eval  is not best practice
  # Relied on global "$deployment_config" variable

  log 'Setting configuration variables'

  printf '\n  %-4s %4s    \n' 'Deployment configuration file: ' "$deployment_config"

  eval $(parse_yaml "$controller_config" "controller_config_")
  eval $(parse_yaml "$deployment_config" "deployment_config_")

  APPNAME=$(echo deployment_config_"${controller_name}"_"${JVM}"_app_name| tr -d '[:space:]')
  TIERNAME=$(echo deployment_config_"${controller_name}"_"${JVM}"_tier_name| tr -d '[:space:]')
  NODENAME=$(echo deployment_config_"${controller_name}"_"${JVM}"_node_name| tr -d '[:space:]')

  CONT_HOST=$(echo controller_config_"${controller_name}"_cont_host| tr -d '[:space:]')
  CONT_PORT=$(echo controller_config_"${controller_name}"_cont_port| tr -d '[:space:]')
  ACCT_NAME=$(echo controller_config_"${controller_name}"_acct_name| tr -d '[:space:]')
  ACCT_KEY=$(echo controller_config_"${controller_name}"_acct_key| tr -d '[:space:]')
  APP_SERVER_AGENT=$(echo controller_config_"${controller_name}"_app_server_agent| tr -d '[:space:]')
  AGENT_INSTALL_LOCATION=$(echo controller_config_"${controller_name}"_agent_install_location| tr -d '[:space:]')
  AGENT_LOCATION=$(echo controller_config_"${controller_name}"_agent_location| tr -d '[:space:]')
  PROXY_HOST=$(echo controller_config_"${controller_name}"_proxy_host| tr -d '[:space:]')
  PROXY_PORT=$(echo controller_config_"${controller_name}"_proxy_port| tr -d '[:space:]')
  SSL=$(echo controller_config_"${controller_name}"_ssl_enabled| tr -d '[:space:]')
  AGENT_ARCHIVE=$(echo controller_config_"${controller_name}"_agent_archive| tr -d '[:space:]')
}

get_vars () {
  # Prints all configuration file values
  log 'Printing configuration...'
  printf '  %-25s%-4s\n' 'APPNAME:' \'"${!APPNAME}"\'
  printf '  %-25s%-4s\n' 'TIERNAME:' \'"${!TIERNAME}"\'
  printf '  %-25s%-4s\n\n' 'NODENAME:' \'"${!NODENAME}"\'

  printf '  %-25s%-4s\n' 'CONT_HOST:' \'"${!CONT_HOST}"\'
  printf '  %-25s%-4s\n' 'CONT_PORT:' \'"${!CONT_PORT}"\'
  printf '  %-25s%-4s\n' 'ACCT_NAME:' \'"${!ACCT_NAME}"\'
  printf '  %-25s%-4s\n' 'ACCT_KEY:' \'"${!ACCT_KEY}"\'
  printf '  %-25s%-4s\n' 'APP_SERVER_AGENT:' \'"${!APP_SERVER_AGENT}"\'
  printf '  %-25s%-4s\n' 'AGENT_INSTALL_LOCATION:' \'"${!AGENT_INSTALL_LOCATION}"\'
  printf '  %-25s%-4s\n' 'AGENT_LOCATION:' \'"${!AGENT_LOCATION}"\'
  printf '  %-25s%-4s\n' 'PROXY_HOST:' \'"${!PROXY_HOST}"\'
  printf '  %-25s%-4s\n' 'PROXY_PORT:' \'"${!PROXY_PORT}"\'
  printf '  %-25s%-4s\n' 'SSL:' \'"${!SSL}"\'
  printf '  %-25s%-4s\n' 'AGENT_ARCHIVE:' \'"${!AGENT_ARCHIVE}"\'

  # Log all values if in debug mode for easier debugging
  log 'Deployment Configuration:' 'DEBUG'
  log 'APPNAME: '\'"${!APPNAME}"\' 'DEBUG'
  log 'TIERNAME: '\'"${!TIERNAME}"\' 'DEBUG'
  log 'NODENAME: '\'"${!NODENAME}"\ 'DEBUG'
  log 'Static Config:'
  log 'CONT_HOST: '\'"${!CONT_HOST}"\' 'DEBUG'
  log 'CONT_PORT: '\'"${!CONT_PORT}"\' 'DEBUG'
  log 'ACCT_NAME: '\'"${!ACCT_NAME}"\' 'DEBUG'
  log 'ACCT_KEY: '\'"${!ACCT_KEY}"\' 'DEBUG'
  log 'APP_SERVER_AGENT: '\'"${!APP_SERVER_AGENT}"\' 'DEBUG'
  log 'AGENT_INSTALL_LOCATION: '\'"${!AGENT_INSTALL_LOCATION}"\' 'DEBUG'
  log 'AGENT_LOCATION: '\'"${!AGENT_LOCATION}"\' 'DEBUG'
  log 'PROXY_HOST: '\'"${!PROXY_HOST}"\' 'DEBUG'
  log 'PROXY_PORT: '\'"${!PROXY_PORT}"\' 'DEBUG'
  log 'SSL: '\'"${!SSL}"\' 'DEBUG'
  log 'AGENT_ARCHIVE: '\'"${!AGENT_ARCHIVE}"\' 'DEBUG'
}

get_controller_name () {
  # Prompts the user for which controller to deploy to ("once")
  if [ -z "$1" ]; then
    log 'Prompting for controller name'
    printf '  %0s\n' 'What controller are you deploying to? [hsbc1test|hostap|hsbc1]'
    read -r response
    case $response in
      hsbc1test)
        controller_name='hsbc1test'
        ;;
      hostap)
        controller_name='hostap'
        ;;
      hsbc1)
        controller_name='hsbc1'
        ;;
      *)
        printf 'Defaulted to hsbc1test as no value entered.'
        controller_name='hsbc1test'
        ;;
    esac
    log 'Controller name: '\'"$controller_name"\' 'INFO' 'yes'
  else
    log 'Controller name: '\'"$1"\' 'INFO' 'yes'
  fi
}

get_jvm_name () {
  # Prompts the user for a JVM name (if not already set via some other method)
  if [ -z "$1" ]; then
    log 'Prompting for JVM name'
    printf '  %0s\n' "Enter WebSphere Server/JVM name:"
    read -r jvm_name
    printf '  %0s\n' "Confirm JVM name? ${jvm_name} [y/N]"
    read -r response
    case $response in
      [yY][eE][sS]|[yY])
        JVM="${jvm_name}"
        printf '  %0s %0s\n' 'JVM name set to :' ${JVM}
        ;;
      *)
        get_jvm_name
        ;;
    esac
  else
    printf '  %0s %0s\n' 'JVM name set to:' "${JVM}"
  fi
  log 'JVM name: '\'"$JVM"\'
}

check_dir () {
  # Adding Agent Directory
  log 'Checking agent dir '\'"$1"\'' exists'
  if [ ! -d "$1" ]; then
    mkdir -m 755 "$1"
    printf '  %0s %0s\n' 'Created' "$1"
    chown wasadm:wasgrp "$1"
    log 'Agent dir created'
  else
    log 'Agent dir exists'
  fi
}

set_was_info () {
  # Written by HSBC, only modified by adding ' 2>/dev/null'
  printf '  %0s\n' " Gathering WAS information..."
  # Find Profile home
  if [[ -n $(find /opt/WebSphere??/ -maxdepth 1 -type d -name profiles 2>/dev/null) ]]; then
    PROFILEHOME=$(find /opt/WebSphere??/ -maxdepth 1 -type d -name profiles 2>/dev/null)
  elif [[ -n $(find /opt/WebSphere??/ -maxdepth 2 -type d -name profiles 2>/dev/null) ]]; then
    PROFILEHOME=$(find /opt/WebSphere??/ -maxdepth 2 -type d -name profiles 2>/dev/null)
  fi
  printf '  %0s\n' " WASProfile=$PROFILEHOME"
  # Find server status script
  ServerStatus=$(find ${PROFILEHOME} -type f -name 'serverStatus.sh' -path "${PROFILEHOME}/*profile/bin/*" ! -path "${PROFILEHOME}/dmgrprofile/*" 2>/dev/null)
  ServerStart=$(find ${PROFILEHOME} -type f -name 'startServer.sh' -path "${PROFILEHOME}/*profile/bin/*" ! -path "${PROFILEHOME}/dmgrprofile/*" 2>/dev/null)
  ServerStop=$(find ${PROFILEHOME} -type f -name 'stopServer.sh' -path "${PROFILEHOME}/*profile/bin/*" ! -path "${PROFILEHOME}/dmgrprofile/*" 2>/dev/null)
  #JVM_STATUS=$( "$ServerStatus" "$JVM" | grep "$JVM" | tail -1 )
}

stop_was_server () {
  # Originally by HSBC
  # Stops a WAS server/JVM
  set_was_info
  log 'Stopping WAS server: '\'"$1"\' 'INFO' 'yes'
  local stop_output="$("$ServerStop" "$1")"
  echo "$stop_output" >&3
}

start_was_server () {
  # Originally by HSBC
  # Starts a WAS server/JVM
  set_was_info
  log 'Starting WAS server: '\'"$1"\' 'INFO' 'yes'
  local start_output="$("$ServerStart" "$1")"; checkXcode $? "Starting $1 Unsuccessful"
  echo "$start_output" >&3
  local jvm_process=$(ps -ef | grep ${JVM})
  if [[ $jvm_process != *"-javaagent:${!AGENT_INSTALL_LOCATION}/${1}/${!APP_SERVER_AGENT}/ver"$ver"/javaagent.jar"* ]]; then
    printf '  %0s %0s\n  %0s\n' 'WARNING' "$1" 'Jvm is not running correctly, either the configuration has failed or the server did not start'
    log 'JVM failed to start' 'ERROR'
  else
    printf '  %0s %-3s %-3s\n' 'INSTALLATION SUCCESSFUL' "${JVM}" 'is running'
    log 'JVM started OK (Installation successful)'
  fi
}

update_arguments () {
  # Originally by HSBC
  log 'Preparing to update JVM arguments' 'INFO' 'yes'
  local arg_output="$("$WASHOME"/AppServer/bin/wsadmin.sh -lang jython -f ./scripts/modifyJVMArg.py -javaagent:"${!AGENT_INSTALL_LOCATION}"/"$JVM"/"${!APP_SERVER_AGENT}"/ver"$ver"/javaagent.jar "$JVM" -Dappdynamics.http.proxyHost="${!PROXY_HOST}" -Dappdynamics.http.proxyPort="${!PROXY_PORT}")"
  echo "$arg_output" >&3
}

back_up_agent () {
  # Backs up an old AppD agent installation
  log 'Backing up old agent(s)'
  local backup_dir="${!AGENT_INSTALL_LOCATION}/backups"
  local old_agents=( $(ls -t /opt/appd/ | grep "$1") )
  if [[ ! -z "$old_agents" ]]; then
    if [[ ! -d "$backup_dir" ]]; then
      mkdir -p "$backup_dir"
    fi
    printf 'Backing up agents...\n'
    for old_agent in "$old_agents"
    do
      mv -f "${!AGENT_INSTALL_LOCATION}"/"$old_agent" "$backup_dir/$old_agent-$(date +'%Y%m%d%H%M%3N').bk"
      checkXcode "$?" 'Backup of '\'"$old_agent"\''unsuccessful'
    done
    log 'Agent backup(s) completed' 'INFO' 'yes'
  fi
}

config_gen () {
  # Inserts values into controller-info.xml
  get_vars
  ver=$( echo ${!APP_SERVER_AGENT}| awk -F "-" '{print $3}')
  config_file="${!AGENT_INSTALL_LOCATION}/${JVM}/${!APP_SERVER_AGENT}/ver"$ver"/conf/controller-info.xml"
  log 'Inserting values into configuration file at '\'"$config_file"\' 'INFO' 'yes'
  log '  Application Name' 'DEBUG'
  sed -i "s/application-name>.*<\/application-name/application-name>"${!APPNAME}"<\/application-name/" "${config_file}"
  checkXcode $? \'"${!APPNAME}"\'' insert unsuccessful'
  log '  Tier Name' 'DEBUG'
  sed -i "s/tier-name>.*<\/tier-name/tier-name>"${!TIERNAME}"<\/tier-name/" "${config_file}"
  checkXcode $? \'"${!TIERNAME}"\'' insert unsuccessful'
  log '  Node Name' 'DEBUG'
  sed -i "s/node-name>.*<\/node-name/node-name>"${!NODENAME}"<\/node-name/" "${config_file}"
  checkXcode $? \'"${!NODENAME}"\'' insert unsuccessful'
  log '  Controller Host' 'DEBUG'
  sed -i "s/controller-host>.*<\/controller-host/controller-host\>"${!CONT_HOST}"\<\/controller-host/" "${config_file}"
  checkXcode $? \'"${!CONT_HOST}"\'' insert unsuccessful'
  log '  Controller Port' 'DEBUG'
  sed -i "s/controller-port>.*<\/controller-port/controller-port\>"${!CONT_PORT}"\<\/controller-port/" "${config_file}"
  checkXcode $? \'"${!CONT_PORT}"\'' insert unsuccessful'
  log '  Account Name' 'DEBUG'
  sed -i "s/account-name>.*<\/account-name/account-name\>"${!ACCT_NAME}"\<\/account-name/" "${config_file}"
  checkXcode $? \'"${!ACCT_NAME}"\'' insert unsuccessful'
  log '  Account Access Key' 'DEBUG'
  sed -i "s/account-access-key>.*<\/account-access-key/account-access-key\>"${!ACCT_KEY}"\<\/account-access-key/" "${config_file}"
  checkXcode $? \'"${!ACCT_KEY}"\'' insert unsuccessful'
  log '  SSL Switch' 'DEBUG'
  sed -i "s/controller-ssl-enabled>.*<\/controller-ssl-enabled/controller-ssl-enabled\>"${!SSL}"\<\/controller-ssl-enabled/" "${config_file}"
  checkXcode $? \'"${!SSL}"\'' insert unsuccessful'
  printf '\n  %0s\n' 'Configuration Done...'
  log 'Completed modification of config file'
}

extract_bin () {
  # Extracts agent binaries from agent package
  log 'Extracting agent binaries from package '\'"${!AGENT_ARCHIVE}"\'
  local instance_location="${!AGENT_INSTALL_LOCATION}/${JVM}/${!APP_SERVER_AGENT}"

  if [ ! -d "$instance_location" ]; then
    mkdir -p "$instance_location"
  fi
  local ext=$(echo "${!AGENT_ARCHIVE}" | awk -F "." '{print $NF}'| tr -d '[:space:]')

  case "$ext" in
    zip)
      unzip -o "${!AGENT_LOCATION}"/"${!AGENT_ARCHIVE}" -d "$instance_location"
      ;;
    gz)
      tar -xzf "${!AGENT_LOCATION}"/"${!AGENT_ARCHIVE}" -C "$instance_location"
      ;;
    tar)
      tar -xzf "${!AGENT_LOCATION}"/"${!AGENT_ARCHIVE}" -C "$instance_location"
      ;;
    *)
      log 'Could not detect package extension - must be .zip, .tar.gz, or .tar' 'ERROR' 'yes'
      exit 1
      ;;
  esac
  log 'Agent binaries extracted succesfully'
}

set_was_home () {
  # Written by HSBC
  # Get a list of WAS servers operating on this host
  if [[ -n $(find /opt/ -maxdepth 1 -type d -name 'WebSphere*') ]]; then
    WASHOME=$(find /opt/ -maxdepth 1 -type d -name 'WebSphere*')
  elif [[ -n $(find /opt/IBM/ -maxdepth 1 -type d -name 'WebSphere*') ]]; then
    WASHOME=$(find /opt/IBM/ -maxdepth 1 -type d -name 'WebSphere*')
  fi
}

run_install () {
  # Main
  clear
  log 'Starting installation' 'INFO' 'yes'
  check_dir '/opt/appd'
  local JVM="$1"
  controller_name="$2"
  get_controller_name "${controller_name}"
  get_jvm_name "$1" # Sets $JVM if a command line argument
  set_was_home
  set_was_info
  stop_was_server "$JVM"
  set_config "$3"
  back_up_agent "$JVM"

  # Install new agent
  extract_bin
  config_gen
  update_arguments
  start_was_server "$JVM"
  log 'Installation completed' 'INFO' 'yes'
}

sim_install () {
  # Simultaneous/selective install
  log 'Entering simultaneous installation mode'
  clear
  printf '  %0s\n' 'The following hosts are going to be upgraded:'

  count=0
  webhosts=( $( ls -1 /opt/appd/| grep -o "$(hostname).*"| grep -v .bk ) )

  for i in "${webhosts[@]}"
  do
    printf '%5s | %0s\n' "${count}" "$i"
    (( count++ ))
  done

  printf '\n  %0s\n' 'Enter the numbers of the jvms you would like to update'
  printf '  %0s\n' 'Enter one or more jvm SPACE SPEPARATED [0 1 2 3 4]'
  read -r response

  response_array=( $(echo $response) )

  for r in "${response_array[@]}"
  do
    printf '%0s %0s\n' 'webhost:' "${webhosts[$r]}"
    run_install "${webhosts[$r]}" "${controller_name}"
  done
}

### Start getopts code ###

log '*** NEW RUN ***' 'INFO'

while getopts ':abisvh' flag;
do
  case "${flag}" in
    a)
        clear
        echo  -e "\033[33;41m WARNING \033[0m \033[33;5m NOOP RUN STARTED \033[0m \033[33;41m WARNING \033[0m"
        get_controller_name
        echo ""
        get_jvm_name
        set_config
        printf '  %0s\n' 'Configuration:'
        get_vars
        exit 0
        ;;
    b)
        JVM="$2"
        controller_name="$3"
        printf '  %0s %0s\n' 'Jvm Host name:' "$JVM"
        printf '  %0s %0s\n' 'Controller name:' "$controller_name"
        run_install "$JVM" "$controller_name"
        ;;
    i)
        run_install
        exit
        ;;
    h)  echo "$usage"; exit;;
    s)  sim_install; exit;;
    v)  echo ' version '$script_version;  exit ;;
    :)
        echo "Missing option argument for -${OPTARG}" >&2
        echo "$usage"
        exit 1
        ;;
    \? )
        echo "Unknown option: -$OPTARG" >&2
        echo "$usage"
        exit 1
        ;;
    *  )
        echo "Unimplemented option: -$OPTARG" >&2
        echo "$usage"
        exit 1
        ;;
  esac
done
# Check a flag has been passed
if [ $OPTIND -eq 1 ]; then
    echo "No options were passed"
    echo "$usage"
    exit 1
fi
shift $((OPTIND-1)) # This tells getopts to move on to the next argument
### End getopts code ###


# ---------------------
# Actual Start of Script:
# ---------------------
exit 0
