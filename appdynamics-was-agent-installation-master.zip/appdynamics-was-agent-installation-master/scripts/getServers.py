import sys
lineSeparator = java.lang.System.getProperty('line.separator')
serverfile = sys.argv[0]
filename = open(serverfile,'w')
sys.stdout = filename

server_list = AdminTask.listServers('[-serverType APPLICATION_SERVER ]').split(lineSeparator)
for server in server_list:
  print AdminConfig.showAttribute(server, 'name')
#endfor
