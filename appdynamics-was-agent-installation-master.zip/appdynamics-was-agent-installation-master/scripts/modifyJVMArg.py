import sys

lineSeparator = java.lang.System.getProperty('line.separator')
appServerAgent = sys.argv[0]
serverName = sys.argv[1]
proxyHost = sys.argv[2]
proxyPort = sys.argv[3]

print "========================================================================="
print "Updating " + serverName + "..."
print
serverid = AdminConfig.getid("/Server:" + serverName + "/JavaProcessDef:/JavaVirtualMachine:/" )
print "CURRENT JVM ARGUMENT:"
print AdminConfig.show(serverid, "genericJvmArguments")
print
jvmarg = AdminConfig.showAttribute(serverid, "genericJvmArguments")
temparg = []
for arg in jvmarg.split(" "):
  if arg.find("-javaagent:") and arg.find("-Dappdynamics")  == -1:
    temparg.append(arg)
  #endif
#endfor
newarg = ' '.join(temparg)
newarg = newarg + " " + proxyHost + " " + proxyPort + " " + appServerAgent
newarg = newarg.strip()
attrs = []
attrs.append(["genericJvmArguments","%s" % (newarg)])
AdminConfig.modify(serverid,attrs)
print "NEW JVM ARGUMENT:"
print AdminConfig.show(serverid, "genericJvmArguments")
print "========================================================================="
AdminConfig.save()
