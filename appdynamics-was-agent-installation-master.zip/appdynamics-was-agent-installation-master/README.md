### Usage ###
 $ ./install_appserver_agent.sh [OPTIONS]

# Usage Information
* Usage: install_appserver_agent.sh [--debug][-h|-v] OPTIONS

* Installation of AppDynamics Java Agents on WebSphere.

### Arguments:
*  -h            Show this help message and exit
*  -v            Print version number

*  -a            Test run, prints config as read by this script
*  -s            Selectively install agents to one or more WAS servers/JVMs
*  -i            Install the agent for a single WAS server/JVM (prompted)
*  -b JVM_NAME   Installs the agent for a single WAS server/JVM (non-interactive)
*                WebSphere server (JVM) name of agent to be updated.
*  --debug       Increases the default INFO log level to DEBUG'
